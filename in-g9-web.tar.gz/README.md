# In-G9 Soluciones de Energía — sitio web

## Estado actual
- ✅ `index.html` — homepage con los 5 pilares de servicio y FAQ
- ✅ `instalacion-electrica-industrial.html` — página de servicio, pilar 01
- ✅ `subestaciones-electricas.html` — página de servicio, pilar 02
- ⬜ `mantenimiento-electrico-industrial.html` — pendiente
- ⬜ `plantas-de-emergencia.html` — pendiente
- ⬜ `optimizacion-electrica-energias-alternativas.html` — pendiente

Mientras estas dos no existan, los links del menú a esas páginas dan 404. Es esperado, no es un error.

## ✅ Dominio confirmado: instalacionelectrica.mx
El sitio corre sobre `https://instalacionelectrica.mx` (dominio raíz, sin `www`) en canonical, `og:url`, todos los bloques `schema.org` y en `sitemap.xml` / `robots.txt`. Ya está reemplazado en el código, no queda ningún placeholder.

## Cómo publicarlo en GitHub Pages

1. Crea un repositorio nuevo en tu cuenta de GitHub (público, o privado si tienes plan Pro/Team, GitHub Pages funciona en ambos casos).
2. Desde tu máquina, dentro de esta carpeta:
   ```bash
   git remote add origin https://github.com/TU-USUARIO/NOMBRE-DEL-REPO.git
   git push -u origin main
   ```
3. En GitHub: **Settings → Pages → Source → Deploy from a branch → main → / (root) → Save**. El archivo `CNAME` que ya está en el repo hace que GitHub reconozca `instalacionelectrica.mx` como el dominio del sitio.
4. En el proveedor donde compraste el dominio, entra a la administración de DNS y agrega:

   **Para que funcione `instalacionelectrica.mx` (sin www):**
   4 registros tipo `A` apuntando a las IPs de GitHub Pages:
   ```
   185.199.108.153
   185.199.109.153
   185.199.110.153
   185.199.111.153
   ```

   **Para que `www.instalacionelectrica.mx` también funcione y redirija al dominio sin www:**
   Un registro `CNAME` con host `www` apuntando a `TU-USUARIO.github.io` (sin `https://`, sin barra al final).

5. La propagación de DNS puede tardar de minutos a un par de horas. Cuando ya resuelva, entra otra vez a **Settings → Pages** y activa **"Enforce HTTPS"** (el candado tarda unos minutos en aparecer disponible, es normal).

## Pendientes fuera del código
- Teléfono, dirección y redes reales, para pasar el schema de `ProfessionalService` a `LocalBusiness` con NAP completo.
- Cifra real de recargo/ahorro por factor de potencia, para reemplazar el ejemplo ilustrativo del panel del home.
- Confirmar los requisitos exactos de CFE para conexión de subestación (la respuesta del FAQ está en términos generales).
- Confirmar si el número 5614314006 debe aparecer también como teléfono público del negocio o solo como WhatsApp.
